# -*- coding: utf-8 -*-
# InsertDynamo.py

import boto3
import unicodedata
from datetime import datetime
import time
import traceback
import os
import json
from botocore.exceptions import ClientError
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer
import re

# --- CONSTANTS & CONFIG ---
LOG_PREFIX = "[InsertDynamo]"
DEFAULT_LISTA_Publication_PK_VALUE = "#listaPublication"
DEFAULT_LIST_ATTRIBUTE_NAME = "TitulosSet"
DEFAULT_COMPOSITE_KEY_SEPARATOR = ':'

# --- BOTO3 UTILITIES ---
serializer = TypeSerializer()
deserializer = TypeDeserializer()

# === HELPER FUNCTION TO CONVERT SETS FOR JSON ---
def convert_sets(obj):
    if isinstance(obj, set): return list(obj)
    if isinstance(obj, dict): return {k: convert_sets(v) for k, v in obj.items()}
    if isinstance(obj, list): return [convert_sets(item) for item in obj]
    return obj

# === NORMALIZATION / FORMATTING HELPERS ===
def normalize_key(text):
    """Normalizes text for keys/search. NFD, lowercase, no diacritics, strip, collapse space."""
    if text is None: return None
    try:
        text = str(text)
        # Use unicodedata for accent removal (native)
        normalized = ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn').lower().strip()
        normalized = ' '.join(normalized.split()) # Collapse multiple spaces
        return normalized if normalized else None
    except Exception as e:
        print(f"{LOG_PREFIX} [WARN] Error during normalize_key for '{text}': {e}. Using simple lower/strip.")
        normalized = str(text).lower().strip()
        return normalized if normalized else None

def format_sortable_date(date_str):
    """Formats various date strings into YYYY-MM-DD. Returns None if parsing fails."""
    if date_str is None: return None
    original_str = str(date_str).strip()
    # Prioritize YYYY-MM-DD
    try: return datetime.strptime(original_str, "%Y-%m-%d").strftime('%Y-%m-%d')
    except ValueError: pass

    supported_formats = ["%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y", "%d/%m/%y", "%y-%m-%d", "%d.%m.%Y", "%Y.%m.%d", "%Y"]
    for fmt in supported_formats:
        try:
            if fmt == "%Y" and len(original_str) == 4 and original_str.isdigit():
                 return datetime.strptime(original_str, fmt).strftime('%Y-01-01')
            elif fmt != "%Y":
                dt = datetime.strptime(original_str, fmt)
                year = dt.year + 2000 if dt.year < 70 else dt.year + 1900 if dt.year < 100 else dt.year
                return f"{year:04d}-{dt.month:02d}-{dt.day:02d}"
        except (ValueError, TypeError): continue
    print(f"{LOG_PREFIX} [WARN] Could not parse date '{original_str}' into YYYY-MM-DD. Returning None.")
    return None

def split_and_normalize(text, delimiter=','):
    """Splits string, normalizes each part, returns list of non-empty strings."""
    if not isinstance(text, str) or not text.strip(): return []
    # Handle potential lists passed directly (e.g., from DB read)
    if isinstance(text, (list, set)):
        items_to_process = text
    else:
        items_to_process = text.split(delimiter)
    # Normalize and filter
    items = [normalize_key(item) for item in items_to_process]
    return [item for item in items if item] # Filter out None or empty results from normalize_key

# === GENERAL DYNAMODB HELPERS ===
def clean_dynamodb_item(item_dict, partition_key_name, sort_key_name):
    """ Cleans dict for DynamoDB: Checks PK/SK, removes Nones/empty strings, cleans lists/sets. """
    cleaned_item = {}
    key_attributes = [partition_key_name, sort_key_name]
    for key_name in key_attributes:
        key_value = item_dict.get(key_name)
        key_value_str = str(key_value).strip() if key_value is not None else ""
        if not key_value_str: raise ValueError(f"Critical DB Error: Primary key '{key_name}' cannot be empty.")
        cleaned_item[key_name] = key_value_str # Store original type if not string? No, PK/SK usually strings.

    for k, v in item_dict.items():
        if k in key_attributes: continue
        if isinstance(v, str):
            stripped_v = v.strip()
            if stripped_v: cleaned_item[k] = stripped_v
        elif isinstance(v, (list, set)):
            cleaned_collection_items = []
            for item in v:
                if item is not None:
                    str_item = str(item).strip()
                    if str_item: cleaned_collection_items.append(str_item)
            if cleaned_collection_items:
                 # Store as list ('L') unless explicitly a set originally ('SS')
                 # Forcing List type 'L' here for simplicity in main item storage
                 cleaned_item[k] = list(cleaned_collection_items)
        elif isinstance(v, (int, float, bool, bytes)):
             if v is not None: cleaned_item[k] = v
        elif isinstance(v, dict):
             if v: cleaned_item[k] = v
    return cleaned_item

def convert_dict_to_dynamodb_item(py_dict):
    """Converts a Python dictionary to DynamoDB attribute-value format."""
    try:
        if not py_dict: raise ValueError("Cannot serialize an empty dictionary.")
        return {k: serializer.serialize(v) for k, v in py_dict.items()}
    except (TypeError, AttributeError) as e: print(f"{LOG_PREFIX} [ERROR] DynamoDB Serialization Error: {py_dict}"); raise TypeError(f"DynamoDB Serialization Error: {e}")
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] Unexpected DynamoDB Serialization Error: {py_dict}"); raise

def _create_index_transact_item(operation: str, prefix: str, suffix_norm: str, composite_sort_key_ref: str, table_name: str, pk_name: str, sk_name: str):
    """Helper for index items. PK=Prefix#NormValue, SK=CompositeKey (Main Item PK)."""
    if not suffix_norm or not composite_sort_key_ref: return None, None
    index_pk = f"{prefix}#{suffix_norm}"; index_sk = str(composite_sort_key_ref)
    index_item_key_dict = { pk_name: index_pk, sk_name: index_sk }
    try:
        if not index_item_key_dict[pk_name] or not index_item_key_dict[sk_name]: raise ValueError(f"Index key empty: PK='{index_pk}', SK='{index_sk}'")
        dynamodb_index_item_key = convert_dict_to_dynamodb_item(index_item_key_dict)
        if operation == 'Put': return {'Put': {'TableName': table_name, 'Item': dynamodb_index_item_key}}, index_item_key_dict
        elif operation == 'Delete': return {'Delete': {'TableName': table_name, 'Key': dynamodb_index_item_key}}, index_item_key_dict
        else: raise ValueError(f"Invalid operation '{operation}'")
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] Skipping index {operation} for PK='{index_pk}', SK='{index_sk}': {e}"); return None, None


# === ATOMIC UPDATE FUNCTION (Stores Lists in Main Item) ===
def handle_dynamodb_update_atomic(payload: dict, dynamodb_table_name: str, dynamodb_client, partition_key_name: str, sort_key_name: str, list_pk_value: str, list_attr_name: str):
    # (Function remains unchanged from previous version)
    print(f"{LOG_PREFIX} Starting handle_dynamodb_update_atomic (Storing Lists) for table: {dynamodb_table_name}")
    titulo_original = payload.get("Titulo"); nome_Publication = payload.get("Nome_da_Publication"); data_Publication_original = payload.get("Data")
    tipo_Publication = payload.get("Tipo_de_Publication"); especialidade_str = payload.get("Especialidade"); autor_str = payload.get("Autor"); categoria1_str = payload.get("Categoria_1"); categoria2_str = payload.get("Categoria_2"); paginas = payload.get("Paginas")
    separator = DEFAULT_COMPOSITE_KEY_SEPARATOR; composite_id = f"{titulo_original}{separator}{nome_Publication}"
    required_fields = { "Titulo": titulo_original, "Data": data_Publication_original, "Nome_da_Publication": nome_Publication }; missing = [f for f, v in required_fields.items() if v is None or (isinstance(v, str) and not v.strip())];
    if missing: raise ValueError(f"DB Update Input Error: Required values missing: {', '.join(missing)}")
    normalized_pk_main = composite_id; sortable_data_sk_main = format_sortable_date(data_Publication_original); original_nome_publication_sk_list = nome_Publication
    especialidade_list_normalized = split_and_normalize(especialidade_str); autor_list_normalized = split_and_normalize(autor_str); categoria1_list_normalized = split_and_normalize(categoria1_str); categoria2_list_normalized = split_and_normalize(categoria2_str); normalized_tipo_Publication = normalize_key(tipo_Publication) if tipo_Publication else None
    if not normalized_pk_main or not sortable_data_sk_main or not original_nome_publication_sk_list: raise ValueError(f"DB Update Key Error: PK ('{normalized_pk_main}'), SK ('{sortable_data_sk_main}'), or ListSK ('{original_nome_publication_sk_list}') is empty.")
    transact_items = []; processed_keys_log = []
    main_item_dict = { partition_key_name: normalized_pk_main, sort_key_name: sortable_data_sk_main, 'Tipo_de_Publication': tipo_Publication, 'Especialidade': especialidade_list_normalized, 'Autor': autor_list_normalized, 'Categoria_1': categoria1_list_normalized, 'Categoria_2': categoria2_list_normalized, 'Paginas': paginas }
    try:
        cleaned_main_item = clean_dynamodb_item(main_item_dict.copy(), partition_key_name, sort_key_name); dynamodb_main_item = convert_dict_to_dynamodb_item(cleaned_main_item)
        transact_items.append({'Put': {'TableName': dynamodb_table_name, 'Item': dynamodb_main_item}}); main_item_key_log = {partition_key_name: normalized_pk_main, sort_key_name: sortable_data_sk_main}
        processed_keys_log.append({"operation": "Put", "type": "MainItem", "key": main_item_key_log}); print(f"{LOG_PREFIX} [DEBUG] Prepared main item Put: Key={main_item_key_log}")
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] Failed prep main item PK='{normalized_pk_main}', SK='{sortable_data_sk_main}': {e}"); raise RuntimeError(f"Failed prep main item: {e}")
    index_map = { "Esp": especialidade_list_normalized, "Aut": autor_list_normalized, "Cat1": categoria1_list_normalized, "Cat2": categoria2_list_normalized }
    for prefix, norm_list in index_map.items():
        if isinstance(norm_list, list):
            for norm_val in norm_list:
                idx_item_tx, idx_key_log = _create_index_transact_item('Put', prefix, norm_val, composite_id, dynamodb_table_name, partition_key_name, sort_key_name)
                if idx_item_tx: transact_items.append(idx_item_tx); processed_keys_log.append({"operation": "Put", "type": f"Index_{prefix}", "key": idx_key_log})
    if normalized_tipo_Publication:
        idx_item_tx, idx_key_log = _create_index_transact_item('Put', "Tipo", normalized_tipo_Publication, composite_id, dynamodb_table_name, partition_key_name, sort_key_name)
        if idx_item_tx: transact_items.append(idx_item_tx); processed_keys_log.append({"operation": "Put", "type": "Index_Tipo", "key": idx_key_log})
    list_item_key_dict = { partition_key_name: list_pk_value, sort_key_name: original_nome_publication_sk_list }
    try:
        dynamodb_list_item_key = convert_dict_to_dynamodb_item(list_item_key_dict); value_to_add_set = {'SS': [titulo_original]}
        update_item_tx = { 'Update': { 'TableName': dynamodb_table_name, 'Key': dynamodb_list_item_key, 'UpdateExpression': f"ADD #listAttr :valueToAddSet", 'ExpressionAttributeNames': {'#listAttr': list_attr_name}, 'ExpressionAttributeValues': {':valueToAddSet': value_to_add_set} } }
        transact_items.append(update_item_tx); processed_keys_log.append({"operation": "Update (Add to Set)", "type": "ListItem", "key": list_item_key_dict, "value_added": titulo_original}); print(f"{LOG_PREFIX} [DEBUG] Prepared list item Update (ADD): Key={list_item_key_dict}")
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] Failed prep list item update Key={list_item_key_dict}: {e}"); raise RuntimeError(f"Failed prep list item update: {e}")
    if not transact_items: raise ValueError(f"{LOG_PREFIX} DB Error Tx-Update: No items prepared.")
    if len(transact_items) > 100: raise ValueError(f"{LOG_PREFIX} DB Error Tx-Update: Items ({len(transact_items)}) exceed limit (100).")
    print(f"{LOG_PREFIX} [DEBUG] Attempting transaction with {len(transact_items)} items.");
    try:
        response = dynamodb_client.transact_write_items(TransactItems=transact_items)
        print(f"{LOG_PREFIX} DB Tx-Update Success for Composite ID: '{composite_id}'. Status: {response.get('ResponseMetadata', {}).get('HTTPStatusCode')}")
    except ClientError as e:
        # (Error logging remains the same)
        error_code = e.response.get('Error', {}).get('Code', 'Unknown'); error_message = e.response.get('Error', {}).get('Message', str(e)); cancellation_reasons = e.response.get('CancellationReasons')
        print(f"{LOG_PREFIX} [ERROR] DB Tx-Update ClientError [{error_code}]: {error_message} for '{composite_id}'");
        if cancellation_reasons: print(f"{LOG_PREFIX} [ERROR] Cancellation Reasons: {cancellation_reasons}"); # Log details...
        else: print(f"{LOG_PREFIX} [ERROR] Full ClientError Response: {e.response}")
        raise
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] DB Tx-Update Unexpected: {e}\n{traceback.format_exc()}"); raise RuntimeError(f"DB Tx Update Unexpected Error: {str(e)}")
    success_msg = f"DB Atomic Update Success: Transaction ({len(transact_items)} items) completed for '{composite_id}'."; print(success_msg)
    return { "message": success_msg, "transactionItemsAttempted": len(transact_items), "processedKeys": processed_keys_log }


# === ATOMIC REMOVAL FUNCTION (Modified to Fetch Date/SK Internally) ===
def handle_dynamodb_removal_atomic(
    payload: dict,
    dynamodb_table_name: str,
    dynamodb_client, # Use low-level client for transact_write_items and query
    partition_key_name: str,
    sort_key_name: str,
    list_pk_value: str,
    list_attr_name: str,
    separator: str = DEFAULT_COMPOSITE_KEY_SEPARATOR
):
    """
    Performs an atomic REMOVAL using TransactWriteItems for a single content item.
    - Fetches the main item using Composite Key to get its Sort Key (Date).
    - Deletes the main document item (PK=CompositeID, SK=Date).
    - Deletes associated index items based on normalized values FROM THE PAYLOAD.
    - Deletes the Original Title from the TitulosSet of the publication list item.

    Args:
        payload (dict): Must contain the ORIGINAL values:
                        'Titulo', 'Nome_da_Publication', and potentially
                        'Tipo_de_Publication', 'Especialidade', 'Autor',
                        'Categoria_1', 'Categoria_2' to find index items.
                        *** 'Data' is NO LONGER required in the payload. ***
        dynamodb_table_name (str): Name of the DynamoDB table.
        dynamodb_client: Initialized low-level DynamoDB client.
        partition_key_name (str): Name of the table's partition key attribute.
        sort_key_name (str): Name of the table's sort key attribute.
        list_pk_value (str): Partition key value for the publication list item.
        list_attr_name (str): Attribute name holding the set of titles.
        separator (str): Separator used in the composite key.

    Returns: dict: Summary of the deletion attempt.
    Raises: ValueError, ClientError, RuntimeError.
    """
    print(f"{LOG_PREFIX} Starting ATOMIC REMOVAL (fetch SK internally) for table: {dynamodb_table_name}")

    # --- Extract Payload Attributes (Need originals) ---
    titulo_original = payload.get("Titulo")
    nome_Publication_original = payload.get("Nome_da_Publication")
    # data_Publication_original = payload.get("Data") # <<< REMOVED - We will fetch this

    # Get original strings for multi-value fields
    tipo_Publication_orig = payload.get("Tipo_de_Publication")
    especialidade_str_orig = payload.get("Especialidade")
    autor_str_orig = payload.get("Autor")
    categoria1_str_orig = payload.get("Categoria_1")
    categoria2_str_orig = payload.get("Categoria_2")

    # --- Validate REQUIRED fields for key reconstruction (excluding Data now) ---
    required_fields = { "Titulo": titulo_original, "Nome_da_Publication": nome_Publication_original }
    missing = [f for f, v in required_fields.items() if v is None or (isinstance(v, str) and not v.strip())]
    if missing:
        raise ValueError(f"DB Atomic Removal Input Error: Required values missing from payload: {', '.join(missing)}")

    # --- Reconstruct Keys needed (Part 1) ---
    composite_id_pk_main = f"{titulo_original}{separator}{nome_Publication_original}"
    original_nome_publication_sk_list = nome_Publication_original # For list item

    if not composite_id_pk_main: raise ValueError(f"DB Atomic Removal Error: Composite ID (PK Main) became empty.")
    if not original_nome_publication_sk_list: raise ValueError(f"DB Atomic Removal Error: Original Publication Name (SK List) became empty.")

    # --- Step 1: Fetch the main item to get its Sort Key (Data) ---
    fetched_sk_main = None
    fetched_item_details = {} # Store fetched item for potential future use
    print(f"{LOG_PREFIX} [DEBUG] Removal - Fetching item to get SK. Querying PK='{composite_id_pk_main}'")
    try:
        query_response = dynamodb_client.query(
            TableName=dynamodb_table_name,
            KeyConditionExpression=f"#pk = :pkval",
            ExpressionAttributeNames={'#pk': partition_key_name},
            ExpressionAttributeValues={':pkval': {'S': composite_id_pk_main}},
            Limit=1 # We only expect/need one item
        )
        items_dynamo = query_response.get('Items', [])
        if not items_dynamo:
            # Item doesn't exist. Maybe already deleted?
            # Option 1: Treat as success (idempotency) - log warning and return
            # Option 2: Raise error
            msg = f"DB Atomic Removal Warning: Main item not found for PK='{composite_id_pk_main}'. Cannot get SK. Assuming already deleted or never existed."
            print(f"{LOG_PREFIX} {msg}")
            # If item not found, we can't delete indices derived from it or remove from list reliably.
            # Let's return a specific message indicating this.
            return { "message": msg, "transactionItemsAttempted": 0, "processedKeys": [], "status": "NOT_FOUND" }
            # Or raise ValueError(msg) if non-existence should be an error

        # Deserialize the fetched item to easily access the sort key
        item_py = {k: deserializer.deserialize(v) for k, v in items_dynamo[0].items()}
        fetched_item_details = item_py # Store it
        fetched_sk_main = item_py.get(sort_key_name)

        if fetched_sk_main is None: # Check if SK exists in the fetched item
             raise ValueError(f"DB Atomic Removal Error: Sort Key '{sort_key_name}' not found in fetched item for PK='{composite_id_pk_main}'. Item Data: {item_py}")

        print(f"{LOG_PREFIX} [DEBUG] Removal - Successfully fetched item. Found SK ('{sort_key_name}') = '{fetched_sk_main}'")

    except ClientError as e:
        print(f"{LOG_PREFIX} [ERROR] DB Atomic Removal: ClientError while fetching item SK for PK='{composite_id_pk_main}': {e}")
        raise # Re-raise critical error during fetch
    except Exception as e:
        print(f"{LOG_PREFIX} [ERROR] DB Atomic Removal: Unexpected error while fetching item SK for PK='{composite_id_pk_main}': {e}")
        print(traceback.format_exc())
        raise RuntimeError(f"Unexpected error fetching item SK: {e}")

    # --- Now we have all keys: composite_id_pk_main and fetched_sk_main ---

    # --- Regenerate NORMALIZED keys for index items (same as before) ---
    # Use original values from payload, NOT necessarily from fetched_item_details
    # (because fetched item might store lists, but we need originals for split_and_normalize)
    especialidade_list_normalized = split_and_normalize(especialidade_str_orig)
    autor_list_normalized = split_and_normalize(autor_str_orig)
    categoria1_list_normalized = split_and_normalize(categoria1_str_orig)
    categoria2_list_normalized = split_and_normalize(categoria2_str_orig)
    normalized_tipo_Publication = normalize_key(tipo_Publication_orig) if tipo_Publication_orig else None
    # (Logging for these normalized keys remains the same)
    print(f"{LOG_PREFIX} [DEBUG] Removal - Normalized Keys for Index Deletion (from payload): Esp={especialidade_list_normalized}, Aut={autor_list_normalized}, Cat1={categoria1_list_normalized}, Cat2={categoria2_list_normalized}, Tipo={normalized_tipo_Publication}")

    # --- Prepare Transaction Items for Deletion ---
    transact_items = []; processed_keys_log = []

    # 1. Main Item Delete (PK=CompositeDocID, SK=Fetched Date) - CRITICAL
    #    Use the SK fetched from the database query
    main_item_key_dict = { partition_key_name: composite_id_pk_main, sort_key_name: fetched_sk_main }
    try:
        dynamodb_main_item_key = convert_dict_to_dynamodb_item(main_item_key_dict)
        transact_items.append({'Delete': {'TableName': dynamodb_table_name, 'Key': dynamodb_main_item_key}})
        processed_keys_log.append({"operation": "Delete", "type": "MainItem", "key": main_item_key_dict})
        print(f"{LOG_PREFIX} [DEBUG] Removal - Prepared Main Item Delete: Key={main_item_key_dict}")
    except Exception as e:
        print(f"{LOG_PREFIX} [ERROR] Failed prep main item delete Key={main_item_key_dict}: {e}")
        raise RuntimeError(f"Failed prep main item delete Key={main_item_key_dict}: {e}")

    # 2. Index Items Delete (same as before)
    #    Uses normalized values from payload and composite_id_pk_main
    index_map = { "Esp": especialidade_list_normalized, "Aut": autor_list_normalized, "Cat1": categoria1_list_normalized, "Cat2": categoria2_list_normalized }
    for prefix, norm_list in index_map.items():
        if isinstance(norm_list, list):
            for norm_val in norm_list:
                idx_item_tx, idx_key_log = _create_index_transact_item('Delete', prefix, norm_val, composite_id_pk_main, dynamodb_table_name, partition_key_name, sort_key_name)
                if idx_item_tx: transact_items.append(idx_item_tx); processed_keys_log.append({"operation": "Delete", "type": f"Index_{prefix}", "key": idx_key_log}); print(f"{LOG_PREFIX} [DEBUG] Removal - Prepared Index Delete {prefix}: Key={idx_key_log}")
                else: print(f"{LOG_PREFIX} [WARN] Removal - Skipped Index Delete prep for {prefix}#{norm_val}")
    if normalized_tipo_Publication:
        idx_item_tx, idx_key_log = _create_index_transact_item('Delete', "Tipo", normalized_tipo_Publication, composite_id_pk_main, dynamodb_table_name, partition_key_name, sort_key_name)
        if idx_item_tx: transact_items.append(idx_item_tx); processed_keys_log.append({"operation": "Delete", "type": "Index_Tipo", "key": idx_key_log}); print(f"{LOG_PREFIX} [DEBUG] Removal - Prepared Index Delete Tipo: Key={idx_key_log}")
        else: print(f"{LOG_PREFIX} [WARN] Removal - Skipped Index Delete prep for Tipo#{normalized_tipo_Publication}")

    # 3. List/Set Update Item (DELETE Original Title) - (same as before)
    list_item_key_dict = { partition_key_name: list_pk_value, sort_key_name: original_nome_publication_sk_list }
    try:
        dynamodb_list_item_key = convert_dict_to_dynamodb_item(list_item_key_dict); value_to_remove_set = {'SS': [titulo_original]}
        update_item_tx = { 'Update': { 'TableName': dynamodb_table_name, 'Key': dynamodb_list_item_key, 'UpdateExpression': f"DELETE #listAttr :valueToRemoveSet", 'ExpressionAttributeNames': {'#listAttr': list_attr_name}, 'ExpressionAttributeValues': {':valueToRemoveSet': value_to_remove_set}, } }
        transact_items.append(update_item_tx); processed_keys_log.append({"operation": "Update (Delete from Set)", "type": "ListItem", "key": list_item_key_dict, "value_removed": titulo_original}); print(f"{LOG_PREFIX} [DEBUG] Removal - Prepared list item Update (DELETE): Key={list_item_key_dict}")
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] Failed prep list item delete update Key={list_item_key_dict}: {e}"); raise RuntimeError(f"Failed prep list item delete update: {e}")

    # --- Perform Atomic Transaction --- (same as before)
    if not transact_items: print(f"{LOG_PREFIX} [WARN] DB Atomic Removal: No ops prepared for '{titulo_original}'."); return { "message": f"DB Atomic Removal: No ops prepared for '{titulo_original}'.", "transactionItemsAttempted": 0, "processedKeys": processed_keys_log }
    if len(transact_items) > 100: raise ValueError(f"Cannot remove atomically: Tx size ({len(transact_items)}) exceeds limit for '{titulo_original}'.")

    print(f"{LOG_PREFIX} [DEBUG] Attempting removal transaction with {len(transact_items)} items.");
    try:
        response = dynamodb_client.transact_write_items(TransactItems=transact_items)
        status_code = response.get('ResponseMetadata', {}).get('HTTPStatusCode'); print(f"{LOG_PREFIX} DB Tx-Removal Success for original title: '{titulo_original}'. Status: {status_code}")
    except ClientError as e:
        # (Error logging remains the same)
        error_code = e.response.get('Error', {}).get('Code', 'Unknown'); error_message = e.response.get('Error', {}).get('Message', str(e)); cancellation_reasons = e.response.get('CancellationReasons')
        print(f"{LOG_PREFIX} [ERROR] DB Tx-Removal ClientError [{error_code}]: {error_message} for '{titulo_original}'")
        if cancellation_reasons: print(f"{LOG_PREFIX} [ERROR] Cancellation Reasons: {cancellation_reasons}"); # Log details...
        else: print(f"{LOG_PREFIX} [ERROR] Full ClientError Response: {e.response}")
        raise
    except Exception as e: print(f"{LOG_PREFIX} [ERROR] DB Tx-Removal Unexpected: {e}\n{traceback.format_exc()}"); raise RuntimeError(f"DB Tx Removal Unexpected Server Error: {str(e)}")

    success_msg = f"DB Atomic Removal Success: Transaction completed. Targeted {len(processed_keys_log)} operations for '{titulo_original}'."; print(success_msg)
    return { "message": success_msg, "transactionItemsAttempted": len(transact_items), "processedKeys": processed_keys_log, "status": "DELETED" } # Add status field